
// import './App.css'
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import "@fortawesome/fontawesome-free/css/all.min.css";
import Navbar from './components/Navbar'
import CardPage from './components/CardPage';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import CartPage from './components/CartPage';

function App() {
  

  return (
    <>
      <BrowserRouter>
      <Navbar/>
      <Routes>
        <Route path="/" element={<CardPage/>}></Route>
        <Route path="/cartpage" element={<CartPage/>}></Route>
      </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
