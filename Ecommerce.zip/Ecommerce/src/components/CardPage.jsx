import React from 'react';
import {
    MDBCard,
    MDBCardBody,
    MDBCardTitle,
    MDBCardText,
    MDBCardImage,
    MDBBtn,
    MDBRow,
    MDBCol
} from 'mdb-react-ui-kit';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from './CartSlice';

export default function CardPage() {

    const items = useSelector((state)=> state.allCart.items);
    const dispatch = useDispatch();



    return (
            <MDBCard className='m-2'>
            <MDBRow className='m-2'>
                {items.map((item)=>(
                    <MDBCol key={item.id} size="2" >
                    <MDBCardImage src={item.img} position='top' alt='...' />
            <MDBCardBody className='m-2'>
                        <MDBCardTitle>{item.title}</MDBCardTitle>
                        <MDBCardText>
                            {item.price}
                        </MDBCardText>
                        <MDBBtn onClick={()=>dispatch(addToCart(item))}>Add to cart</MDBBtn>
            </MDBCardBody>
                </MDBCol>
                ))}
            </MDBRow>
        </MDBCard>
    );
}