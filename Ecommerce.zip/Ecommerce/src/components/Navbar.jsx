import React, { useEffect } from 'react';
import {
  MDBContainer,
  MDBNavbar,
  MDBNavbarBrand,
  MDBBtn,
  MDBInputGroup
} from 'mdb-react-ui-kit';
import { Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { getCartTotal } from './CartSlice';

export default function Navbar() {

  const{cart,totalQuantity}  = useSelector((state)=>state.allCart);

  const dispatch = useDispatch();

  useEffect(()=>{
    dispatch(getCartTotal());
  },[cart])

  return (
    <MDBNavbar light bgColor='light'>
      <MDBContainer fluid>
        <MDBNavbarBrand>Navbar</MDBNavbarBrand>
        <Link to="/">All Products</Link>
        <MDBInputGroup tag="form" className='d-flex w-auto mb-3'>
          <input className='form-control' placeholder="Type query" aria-label="Search" type='Search' />
          <MDBBtn outline>Search</MDBBtn>
          <Link to="/cartpage"><MDBBtn className='bg-dark text-light mx-2'>
            CART <span className='p-1 bg-danger rounded-circle '>{totalQuantity}</span>
          </MDBBtn></Link>

        </MDBInputGroup>
      </MDBContainer>
    </MDBNavbar>
  );
}