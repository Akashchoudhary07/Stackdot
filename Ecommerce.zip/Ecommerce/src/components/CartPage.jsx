import React, { useEffect } from 'react';
import {
    MDBContainer,
    MDBRow,
    MDBCol,
    MDBCard,
    MDBCardBody,
    MDBCardTitle,
    MDBCardText,
    MDBCardImage,
    MDBBtn,
    MDBListGroup,
    MDBListGroupItem
} from 'mdb-react-ui-kit';
import { useDispatch, useSelector } from 'react-redux';
import { decrementItem, getCartTotal, incrementItem, removeItem } from './CartSlice';

const CartPage = () => {

    const {cart,totalQuantity,totalPrice} = useSelector((state)=> state.allCart);

    const dispatch = useDispatch();

    useEffect(()=>{
        dispatch(getCartTotal());
    },[cart])

    return (
        <MDBContainer className="my-5">
            <h2 className="text-center mb-4">🛒 Shopping Cart</h2>
            <MDBRow>
                <MDBCol md="8">
                    {
                        cart.map((data)=>(
                            <MDBCard className="mb-3">
                            <MDBRow className="g-0">
                            <MDBCol md="4">
                                <MDBCardImage
                                    src={data.img}
                                    alt="Product"
                                    fluid
                                />
                            </MDBCol>
                            <MDBCol md="8">
                                <MDBCardBody>
                                    <MDBCardTitle>{data.title}</MDBCardTitle>
                                    <MDBCardText>Price: Rs.{data.price}</MDBCardText>

                                    <div className="d-flex align-items-center gap-3 mb-3">
                                        <MDBBtn onClick={()=>dispatch(decrementItem(data.id))} size="sm" color="dark">-</MDBBtn>
                                        <span className="fs-5">{data.quantity}</span>
                                        <MDBBtn onClick={()=>dispatch(incrementItem(data.id))} size="sm" color="dark">+</MDBBtn>
                                    </div>

                                    <MDBBtn onClick={()=>dispatch(removeItem(data.id))} size="sm" color="danger">Remove</MDBBtn>
                                </MDBCardBody>
                            </MDBCol>
                        </MDBRow>
                    </MDBCard>
                        ))
                    }
                </MDBCol>

                {/* Right Side - Billing */}
                <MDBCol md="4">
                    <MDBCard>
                        <MDBCardBody>
                            <h4>💰 Billing Summary</h4>
                            <MDBListGroup flush className="mt-3">
                                <MDBListGroupItem className="d-flex justify-content-between">
                                    <span>Total-Quantity</span>
                                    <span>{totalQuantity}</span>
                                </MDBListGroupItem>
                                <MDBListGroupItem className="d-flex justify-content-between fw-bold">
                                    <span>Total-Amout</span>
                                    <span>Rs.{totalPrice}</span>
                                </MDBListGroupItem>
                            </MDBListGroup>

                            <MDBBtn block color="success" className="mt-4">
                                Proceed to Checkout
                            </MDBBtn>
                        </MDBCardBody>
                    </MDBCard>
                </MDBCol>
            </MDBRow>
        </MDBContainer>
    );
};

export default CartPage;